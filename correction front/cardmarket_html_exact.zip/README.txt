PROJET CARDMARKET — HTML FOURNI PAR L'UTILISATEUR

index.html
  Copie STRICTEMENT identique, octet pour octet, du HTML fourni.

index-preview.html
  Même HTML avec uniquement une balise <base> ajoutée pour permettre
  le chargement des ressources distantes lorsque le fichier est ouvert localement.

index-local-css.html
  Même page, mais les deux feuilles CSS sont référencées localement dans /css.
  Lance download_css.bat ou download_css.ps1 avant de l'ouvrir.

CSS_URLS.txt
  Les deux URLs CSS exactement présentes dans le HTML fourni.

IMPORTANT
  Les CSS eux-mêmes ne sont PAS contenus dans le fichier HTML fourni.
  Le HTML ne contient que leurs URLs. Les scripts fournis permettent de les
  télécharger directement depuis static.cardmarket.com sur ton ordinateur.
