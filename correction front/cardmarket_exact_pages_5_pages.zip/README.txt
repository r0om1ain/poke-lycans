CARDMARKET — COLLECTION DE PAGES HTML EXACTES

Chaque dossier contient :
- index.html : copie STRICTEMENT identique du HTML fourni par l'utilisateur
- index-preview.html : même HTML avec seulement une balise <base> ajoutée pour l'ouvrir localement
- CSS_URLS.txt : feuilles CSS référencées par la page
- JS_URLS.txt : scripts JS référencés par la page
- SHA256.txt : vérification d'intégrité

PAGES ACTUELLEMENT COLLECTÉES
1. /fr/Pokemon
2. /fr/Pokemon/Products/Singles
3. /fr/Pokemon/Orders/Sales/Paid
4. /fr/Pokemon/Stock/Offers
5. /fr/Pokemon/Stock/Offers/Singles

IMPORTANT
Les fichiers index.html sont conservés tels qu'ils ont été fournis.
Les CSS/JS distants ne sont pas réécrits ni inventés.
