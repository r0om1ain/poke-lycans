﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Css = Join-Path $Root "css"

New-Item -ItemType Directory -Force -Path $Css | Out-Null

Write-Host "Telechargement du CSS principal..."
Invoke-WebRequest -Uri "https://static.cardmarket.com/img/4121e3b11fc9953850bd9a165ad48afd/static-code/public/styles/master.min.css" -OutFile (Join-Path $Css "master.min.css")

Write-Host "Telechargement du CSS de la page d'accueil connectee..."
Invoke-WebRequest -Uri "https://static.cardmarket.com/img/4121e3b11fc9953850bd9a165ad48afd/static-code/public/styles/startPage_loggedIn.min.css" -OutFile (Join-Path $Css "startPage_loggedIn.min.css")

Write-Host ""
Write-Host "OK : les CSS ont ete enregistres dans le dossier css."
Write-Host "Ouvre ensuite index-local-css.html."
