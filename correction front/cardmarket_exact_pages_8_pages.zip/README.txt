CARDMARKET — COLLECTION DE PAGES HTML EXACTES

Chaque dossier contient :
- index.html : copie STRICTEMENT identique du HTML fourni par l'utilisateur
- index-preview.html : même HTML avec seulement une balise <base> ajoutée
- CSS_URLS.txt : feuilles CSS référencées par la page
- JS_URLS.txt : scripts JS référencés par la page
- SHA256.txt : vérification d'intégrité

PAGES ACTUELLEMENT COLLECTÉES
1. /fr/Pokemon
2. /fr/Pokemon/Products/Singles
3. /fr/Pokemon/Orders/Sales/Paid
4. /fr/Pokemon/Stock/Offers
5. /fr/Pokemon/Stock/Offers/Singles
6. /fr/Pokemon/Products/Singles/Ascended-Heroes/Lillies-Determination-ASC192?language=2
7. /fr/Pokemon/ShoppingCart
8. /fr/Pokemon/Account/Messages

IMPORTANT
Les fichiers index.html sont conservés tels qu'ils ont été fournis.
Les CSS/JS distants ne sont pas réécrits ni inventés.
