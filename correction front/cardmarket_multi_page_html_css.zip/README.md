# Marketplace Pokémon — exercice multi-pages

Pages disponibles :

- `index.html` : accueil inspiré d'une marketplace TCG.
- `singles.html` : catalogue de cartes / Singles.
- `style.css` : feuille de style commune aux deux pages.

Les visuels de cartes sont volontairement recréés en CSS et ne reprennent pas les assets propriétaires du site source.
