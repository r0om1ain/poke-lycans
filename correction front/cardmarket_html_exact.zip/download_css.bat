@echo off
if not exist css mkdir css
curl.exe -L "https://static.cardmarket.com/img/4121e3b11fc9953850bd9a165ad48afd/static-code/public/styles/master.min.css" -o "css\master.min.css"
curl.exe -L "https://static.cardmarket.com/img/4121e3b11fc9953850bd9a165ad48afd/static-code/public/styles/startPage_loggedIn.min.css" -o "css\startPage_loggedIn.min.css"
echo.
echo CSS telecharges. Ouvre index-local-css.html
pause
